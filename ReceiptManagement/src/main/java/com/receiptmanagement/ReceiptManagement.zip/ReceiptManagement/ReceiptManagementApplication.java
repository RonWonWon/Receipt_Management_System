package com.receiptmanagement.ReceiptManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceiptManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReceiptManagementApplication.class, args);
	}

}
